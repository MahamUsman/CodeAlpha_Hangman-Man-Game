"""
CodeAlpha Task 1 — Hangman Game (Full Stack Edition)
Backend: FastAPI

Serves a small REST API that runs the game logic and hands the
frontend only what it's allowed to see (never the answer, unless
the game is over).

Run with:
    uvicorn main:app --reload --port 8000
"""

import random
import string
import uuid
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

MAX_ATTEMPTS = 6  # per task brief: limit incorrect guesses to 6

# ---------------------------------------------------------------------------
# Word bank — Python / programming themed, since this is the Python track.
# Each word has a short hint shown to the player.
# ---------------------------------------------------------------------------
WORD_BANK = [
    {"word": "PYTHON", "hint": "The language this whole internship is about"},
    {"word": "FUNCTION", "hint": "A reusable block of code you call by name"},
    {"word": "VARIABLE", "hint": "A named container that holds a value"},
    {"word": "DICTIONARY", "hint": "Key-value pairs, curly braces, {}"},
    {"word": "ALGORITHM", "hint": "A step-by-step recipe for solving a problem"},
    {"word": "COMPILER", "hint": "Translates source code before it runs (not Python's usual approach)"},
    {"word": "RECURSION", "hint": "A function that calls itself"},
    {"word": "DEBUGGING", "hint": "Hunting down the bug in your code"},
    {"word": "EXCEPTION", "hint": "Raised when something goes wrong at runtime"},
    {"word": "ITERATOR", "hint": "An object you can loop over, one item at a time"},
    {"word": "MODULE", "hint": "A .py file you can import"},
    {"word": "BOOLEAN", "hint": "True or False, nothing in between"},
    {"word": "TUPLE", "hint": "Like a list, but you can't change it"},
    {"word": "LAMBDA", "hint": "An anonymous, one-line function"},
    {"word": "INHERITANCE", "hint": "A class borrowing traits from a parent class"},
]

app = FastAPI(title="CodeAlpha Hangman API", version="1.0.0")

# Allow the frontend (served from a different origin/port, e.g. Live Server
# on :5500 or a plain file:// page) to call this API during local development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory game store: {game_id: game_state}
# Fine for a single-user local project like this internship task.
GAMES: Dict[str, dict] = {}


class NewGameResponse(BaseModel):
    game_id: str
    word_length: int
    hint: str
    max_attempts: int
    attempts_left: int
    masked_word: str
    guessed_letters: List[str]
    status: str


class GuessRequest(BaseModel):
    letter: str = Field(..., min_length=1, max_length=1)


class GuessResponse(BaseModel):
    masked_word: str
    guessed_letters: List[str]
    wrong_letters: List[str]
    attempts_left: int
    status: str  # "playing" | "won" | "lost"
    word: Optional[str] = None  # only revealed when game is over


def _masked_word(word: str, guessed: set) -> str:
    return " ".join(ch if ch in guessed else "_" for ch in word)


def _status(word: str, guessed: set, attempts_left: int) -> str:
    if all(ch in guessed for ch in word):
        return "won"
    if attempts_left <= 0:
        return "lost"
    return "playing"


@app.post("/api/game/new", response_model=NewGameResponse)
def new_game():
    entry = random.choice(WORD_BANK)
    word = entry["word"].upper()
    game_id = str(uuid.uuid4())

    GAMES[game_id] = {
        "word": word,
        "hint": entry["hint"],
        "guessed": set(),
        "wrong": set(),
        "attempts_left": MAX_ATTEMPTS,
    }

    return NewGameResponse(
        game_id=game_id,
        word_length=len(word),
        hint=entry["hint"],
        max_attempts=MAX_ATTEMPTS,
        attempts_left=MAX_ATTEMPTS,
        masked_word=_masked_word(word, set()),
        guessed_letters=[],
        status="playing",
    )


@app.post("/api/game/{game_id}/guess", response_model=GuessResponse)
def guess_letter(game_id: str, body: GuessRequest):
    game = GAMES.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Game not found. Start a new game.")

    letter = body.letter.upper()
    if letter not in string.ascii_uppercase:
        raise HTTPException(status_code=400, detail="Guess must be a single A-Z letter.")

    current_status = _status(game["word"], game["guessed"], game["attempts_left"])
    if current_status != "playing":
        raise HTTPException(status_code=400, detail=f"Game already {current_status}.")

    if letter in game["guessed"] or letter in game["wrong"]:
        raise HTTPException(status_code=400, detail="Letter already guessed.")

    if letter in game["word"]:
        game["guessed"].add(letter)
    else:
        game["wrong"].add(letter)
        game["attempts_left"] -= 1

    status = _status(game["word"], game["guessed"], game["attempts_left"])

    return GuessResponse(
        masked_word=_masked_word(game["word"], game["guessed"]),
        guessed_letters=sorted(game["guessed"]),
        wrong_letters=sorted(game["wrong"]),
        attempts_left=game["attempts_left"],
        status=status,
        word=game["word"] if status in ("won", "lost") else None,
    )


@app.get("/api/game/{game_id}", response_model=GuessResponse)
def get_game(game_id: str):
    game = GAMES.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Game not found.")

    status = _status(game["word"], game["guessed"], game["attempts_left"])
    return GuessResponse(
        masked_word=_masked_word(game["word"], game["guessed"]),
        guessed_letters=sorted(game["guessed"]),
        wrong_letters=sorted(game["wrong"]),
        attempts_left=game["attempts_left"],
        status=status,
        word=game["word"] if status in ("won", "lost") else None,
    )


@app.get("/api/health")
def health():
    return {"status": "ok", "active_games": len(GAMES)}
