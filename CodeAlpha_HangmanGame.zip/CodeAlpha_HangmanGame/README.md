# CodeAlpha_HangmanGame

**CodeAlpha Python Programming Internship — Task 01: Hangman Game**

A full-stack version of the classic Hangman game:

- **Backend:** FastAPI (Python) — game logic, word bank, session state, REST API
- **Frontend:** HTML/CSS/JavaScript — retro amber CRT terminal UI that talks to the backend over `fetch()`

The word list is Python/programming-themed (`PYTHON`, `FUNCTION`, `RECURSION`, etc.) to tie the game back to the internship track.

```
CodeAlpha_HangmanGame/
├── backend/
│   ├── main.py            # FastAPI app: game logic + REST endpoints
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
└── README.md
```

## How it works

- `POST /api/game/new` — starts a new game, returns a `game_id`, the word length, a hint, and attempts left (6, per the task brief).
- `POST /api/game/{game_id}/guess` — submit one letter, get back the updated masked word, wrong letters, attempts left, and status (`playing` / `won` / `lost`). The full word is only ever sent back once the game is over.
- `GET /api/game/{game_id}` — re-fetch current state (handy after a page refresh).
- Game state lives in memory on the server (a plain Python dict keyed by `game_id`), which is enough for a local single-player project like this one.

## Running it locally (Windows / PowerShell)

**1. Backend**

```powershell
cd backend
python -m venv venv
venv\Scripts\Activate.ps1
```

> If PowerShell blocks the activation script with an execution-policy error, run this once (in an admin PowerShell) and try again:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

```powershell
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Leave this terminal running. You should see `Uvicorn running on http://127.0.0.1:8000`.
Visit `http://127.0.0.1:8000/docs` to see the auto-generated Swagger UI for the API.

**2. Frontend**

The frontend is plain HTML/CSS/JS, so it doesn't need a build step. Easiest options:

- Open `frontend/index.html` directly in your browser, **or**
- Serve it (avoids some browsers' quirks with `file://` + fetch):

  ```powershell
  cd frontend
  python -m http.server 5500
  ```

  Then visit `http://127.0.0.1:5500`.

The frontend is hard-coded to call the backend at `http://127.0.0.1:8000` (see `API_BASE` at the top of `script.js`). Change that constant if you run the backend on a different host/port.

**3. macOS / Linux**

Same steps, just activate the venv with `source venv/bin/activate` instead of the PowerShell script.

## Playing

Type a letter and press **Guess** (or click a letter on the on-screen keyboard). You get 6 wrong guesses before the hangman is complete and the game ends. Click **New Game** to get a fresh word at any time.

## For submission

- Push this folder to a GitHub repo named `CodeAlpha_HangmanGame`.
- Record a short video walking through the code and a live game, per the CodeAlpha instructions.
- Post your internship status + video to LinkedIn, tagging @CodeAlpha, and link the repo.
