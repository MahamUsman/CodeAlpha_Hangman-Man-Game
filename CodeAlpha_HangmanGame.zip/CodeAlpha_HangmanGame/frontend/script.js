// ---------------------------------------------------------------------------
// CodeAlpha Task 01 — Hangman Game (frontend)
// Talks to the FastAPI backend running at API_BASE.
// ---------------------------------------------------------------------------

const API_BASE = "http://127.0.0.1:8000";

// ASCII gallows, indexed by number of WRONG guesses made so far (0..6)
const ASCII_STAGES = [
`  +---+
  |   |
      |
      |
      |
      |
=========`,
`  +---+
  |   |
  O   |
      |
      |
      |
=========`,
`  +---+
  |   |
  O   |
  |   |
      |
      |
=========`,
`  +---+
  |   |
  O   |
 /|   |
      |
      |
=========`,
`  +---+
  |   |
  O   |
 /|\\  |
      |
      |
=========`,
`  +---+
  |   |
  O   |
 /|\\  |
 /    |
      |
=========`,
`  +---+
  |   |
  O   |
 /|\\  |
 / \\  |
      |
=========`
];

const els = {
  status: document.getElementById("statusLine"),
  ascii: document.getElementById("asciiArt"),
  attemptsLeft: document.getElementById("attemptsLeft"),
  hint: document.getElementById("hintText"),
  word: document.getElementById("wordDisplay"),
  wrong: document.getElementById("wrongLetters"),
  keyboard: document.getElementById("keyboard"),
  input: document.getElementById("letterInput"),
  guessBtn: document.getElementById("guessBtn"),
  newGameBtn: document.getElementById("newGameBtn"),
  endMessage: document.getElementById("endMessage"),
  connStatus: document.getElementById("connStatus"),
};

let gameId = null;
let gameOver = false;

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

function buildKeyboard() {
  els.keyboard.innerHTML = "";
  ALPHABET.forEach((letter) => {
    const btn = document.createElement("button");
    btn.className = "key";
    btn.textContent = letter;
    btn.dataset.letter = letter;
    btn.addEventListener("click", () => submitGuess(letter));
    els.keyboard.appendChild(btn);
  });
}

function setStatusLine(text) {
  els.status.textContent = text;
}

function setConnStatus(ok, text) {
  els.connStatus.textContent = `● API: ${text}`;
  els.connStatus.className = "conn-status " + (ok ? "ok" : "err");
}

function renderAscii(wrongCount) {
  const stage = ASCII_STAGES[Math.min(wrongCount, ASCII_STAGES.length - 1)];
  els.ascii.textContent = stage;
}

function updateKeyboardState(guessedLetters, wrongLetters) {
  document.querySelectorAll(".key").forEach((btn) => {
    const letter = btn.dataset.letter;
    if (guessedLetters.includes(letter)) {
      btn.disabled = true;
      btn.classList.add("correct");
      btn.classList.remove("wrong");
    } else if (wrongLetters.includes(letter)) {
      btn.disabled = true;
      btn.classList.add("wrong");
      btn.classList.remove("correct");
    } else {
      btn.disabled = gameOver;
      btn.classList.remove("correct", "wrong");
    }
  });
}

function applyState(state, { hint } = {}) {
  const wrongCount = 6 - state.attempts_left;
  renderAscii(wrongCount);
  els.attemptsLeft.textContent = state.attempts_left;
  els.word.textContent = state.masked_word || "";
  els.wrong.textContent = state.wrong_letters && state.wrong_letters.length
    ? state.wrong_letters.join(", ")
    : "(none)";

  if (hint) els.hint.textContent = hint;

  gameOver = state.status !== "playing";
  updateKeyboardState(state.guessed_letters || [], state.wrong_letters || []);

  els.input.disabled = gameOver;
  els.guessBtn.disabled = gameOver;

  if (state.status === "won") {
    setStatusLine("SYSTEM: WORD CRACKED SUCCESSFULLY.");
    showEndMessage(`>>> YOU WIN — THE WORD WAS "${state.word}" <<<`, "won");
  } else if (state.status === "lost") {
    setStatusLine("SYSTEM: OUT OF ATTEMPTS.");
    showEndMessage(`>>> GAME OVER — THE WORD WAS "${state.word}" <<<`, "lost");
  } else {
    setStatusLine("GAME IN PROGRESS — AWAITING INPUT...");
    hideEndMessage();
  }
}

function showEndMessage(text, kind) {
  els.endMessage.textContent = text;
  els.endMessage.className = `end-message ${kind}`;
}

function hideEndMessage() {
  els.endMessage.textContent = "";
  els.endMessage.className = "end-message hidden";
}

async function startNewGame() {
  hideEndMessage();
  setStatusLine("REQUESTING NEW WORD FROM SERVER...");
  els.input.value = "";
  try {
    const res = await fetch(`${API_BASE}/api/game/new`, { method: "POST" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    gameId = data.game_id;
    gameOver = false;
    buildKeyboard();
    applyState(data, { hint: data.hint });
    setConnStatus(true, "connected");
    els.input.focus();
  } catch (err) {
    console.error(err);
    setConnStatus(false, "unreachable");
    setStatusLine(
      "ERROR: Could not reach the backend. Is uvicorn running on port 8000?"
    );
  }
}

async function submitGuess(letterRaw) {
  if (!gameId || gameOver) return;
  const letter = (letterRaw || els.input.value).toUpperCase();
  els.input.value = "";
  if (!letter || !/^[A-Z]$/.test(letter)) {
    setStatusLine("INPUT ERROR: enter a single letter A-Z.");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/game/${gameId}/guess`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ letter }),
    });
    const data = await res.json();
    if (!res.ok) {
      setStatusLine(`SYSTEM: ${data.detail || "invalid guess"}`);
      return;
    }
    applyState(data);
    setConnStatus(true, "connected");
  } catch (err) {
    console.error(err);
    setConnStatus(false, "unreachable");
    setStatusLine("ERROR: lost connection to backend.");
  }
}

els.guessBtn.addEventListener("click", () => submitGuess());
els.input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") submitGuess();
});
els.newGameBtn.addEventListener("click", startNewGame);

// Blinking titlebar indicator, purely decorative
setInterval(() => {
  const el = document.getElementById("clockBlink");
  if (el) el.style.opacity = el.style.opacity === "0" ? "1" : "0";
}, 700);

buildKeyboard();
startNewGame();
